<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class U extends CI_Controller {

	/**
	 * admin login Page for this controller.
	 */
	public function i(){
		if($this->uri->segment(3)){
			header("Location: ".base_url()."welcome/reward/".$this->uri->segment(3));
			die();
		}
	}
	
	
	
	
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */