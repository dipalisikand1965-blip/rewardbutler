<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Configure_access extends CI_Controller {
	
	
    /**
     * Default constructor.
     * 
     * @access	public
     * @since	1.0.0
     */
    function __construct() {
        parent::__construct();
        if (!($this->session->userdata('loggedIN') == 2)) {
            redirect(base_url());
        }
    }
	
	
	/**
	 * profile Page for this controller.
	 */
	public function index(){
		
		$this->load->view('admin/admin_header');
		$this->load->view('admin/admin_navbar');
		$this->load->view('admin/admin_dashboard');
		$this->load->view('admin/admin_footer');
	}
	
	
	//--------------------------------------------------------------------------
    /**
     * This function is used to uploaded profile image.
     */
     public function upload_image() {
        #array to hold the response values to be displayed
        $arr_response = array();

        $info = pathinfo($_FILES['myFile']['name']);
        $ext = $info['extension']; // get the extension of the file
        if (($ext == "GIF" || $ext == "PNG" || $ext == "JPG" || $ext == "jpg" || $ext == 'gif' || $ext == 'png' || $ext == 'jpeg') && ($_FILES["myFile"]["type"] == "image/PNG" || $_FILES["myFile"]["type"] == "image/GIF" || $_FILES["myFile"]["type"] == "image/JPG" || $_FILES["myFile"]["type"] == "image/jpg" ||$_FILES["myFile"]["type"] == "image/jpeg" || $_FILES["myFile"]["type"] == 'image/gif' || $_FILES["myFile"]["type"] == 'image/png') &&
                ($_FILES["myFile"]["size"] < 30485760)) {
            $file = $info['filename'];
            $filename = $_POST['image_profile'] . '_' . uniqid() . '.' . $ext;
            $target = './uploads/' . $filename;
            $file = $_FILES['myFile']['tmp_name'];
            move_uploaded_file($file, $target);            
            
			$arr_response['status'] = SUCCESS;
			$arr_response['filename'] = $filename;
            
        } else {
            $arr_response['status'] = FAILED;
            $arr_response['message'] = "Not a valid File.";
        }
        echo json_encode($arr_response);
    }
	
	//-------------------------------------------------------------
    /**
     * This function is used to load user change password
     * 
     * @access		public
     * @since		1.0.0
     */
    public function change_password() {		
		 
		$this->load->view('admin/admin_header');
		$this->load->view('admin/admin_navbar');
		$this->load->view('admin/change_password');
		$this->load->view('admin/admin_footer');
    }
	
	//--------------------------------------------------------------
    /**
     * This function is used to to update password.
     * 
     * @access		public
     * @since		1.0.0
     */
    public function update_password() {
        //array to store ajax responses
        $arr_response = array('status' => ERR_DEFAULT);

		//Load Required modal
		$this->load->model('configure_access_model', 'obj_con', TRUE);

		$return_val = $this->obj_con->update_password();
		if ($return_val==1) {
			$arr_response['status'] = SUCCESS;
			$arr_response['message'] = 'Password has been updated successfully';
		} elseif ($return_val==2) {
			$arr_response['status'] = DB_ERROR;
			$arr_response['message'] = 'Old Password is incorrect !';
		} else {
			$arr_response['status'] = DB_ERROR;
			$arr_response['message'] = 'Something went Wrong! Please try again';
		}
        echo json_encode($arr_response);
    }
	
	
	//-------------------------------------------------------------------------
    /**
     * Controller to handle logout request
     * 
     * @version 0.0.1
     * @since 0.0.1
     */
    public function logout() {
        $this->session->sess_destroy();
        $arr_response['redirect'] = base_url() . 'login';
        echo json_encode($arr_response);
    }
	
	//-------------------------------------------------------------
    /**
     * This function is used to load user change password
     * 
     * @access		public
     * @since		1.0.0
     */
    public function upload_csv() {		
		 
		$this->load->view('admin/admin_header');
		$this->load->view('admin/admin_navbar');
		$this->load->view('admin/upload_csv');
		$this->load->view('admin/admin_footer');
    }
	
	//--------------------------------------------------------------------------
    /**
     * This function is used to uploaded profile image.
     */
     public function upload_csvFile() {
        #array to hold the response values to be displayed
        $arr_response = array();

        $info = pathinfo($_FILES['myFile']['name']);
        $ext = $info['extension']; // get the extension of the file
        if (($ext == "csv" || $ext == "CSV")&& ($_FILES["myFile"]["size"] < 30485760)) {
            $file = $info['filename'];
            $filename = $_POST['image_profile'] . '_' . uniqid() . '.' . $ext;
            $target = './uploads/' . $filename;
            $file = $_FILES['myFile']['tmp_name'];
            move_uploaded_file($file, $target);            
            
			$arr_response['status'] = SUCCESS;
			$arr_response['filename'] = $filename;
            
        } else {
            $arr_response['status'] = FAILED;
            $arr_response['message'] = "Not a valid File.";
        }
        echo json_encode($arr_response);
    }
	
	//------------------------------------------------------------------------
    /*
     * This function is used to do parsing the csv file
     */
    public function html_parser_csv_file() {
        //array to store ajax responses
        $arr_response = array('status' => ERR_DEFAULT);
		
		ini_set('memory_limit', '-1');
        #load required model
		$this->load->model('configure_access_model', 'obj_con', TRUE);
        
        $return_val = $this->obj_con->read_csv();
		if ($return_val) {
			$arr_response['status'] = SUCCESS;
			$arr_response['message'] = 'file has been added successfully';
		} else {
			$arr_response['status'] = DB_ERROR;
			$arr_response['message'] = 'Something went Wrong! Please try again';
		}
		echo json_encode($arr_response);
    }
	
	
	//-------------------------------------------------------------
    /**
     * This function is used to load user change password
     * 
     * @access		public
     * @since		1.0.0
     */
    public function extract_csv() {		
		#load required model
		$this->load->model('configure_access_model', 'obj_con', TRUE);
        $is_updated = 1;
		$data['csv_data'] = $this->obj_con->get_reward_data($is_updated);
		
		$this->load->view('admin/admin_header');
		$this->load->view('admin/admin_navbar');
		$this->load->view('admin/extract_csv',$data);
		$this->load->view('admin/admin_footer');
    }
	
	//-------------------------------------------------------------
    /**
     * This function is used to load user change password
     * 
     * @access		public
     * @since		1.0.0
     */
    public function export_all() {		
		#load required model
		$this->load->model('configure_access_model', 'obj_con', TRUE);
        $is_updated = 1;
		$data['csv_data'] = $this->obj_con->get_reward_data();
		
		$this->load->view('admin/admin_header');
		$this->load->view('admin/admin_navbar');
		$this->load->view('admin/export_all_data',$data);
		$this->load->view('admin/admin_footer');
    }
	
	//-------------------------------------------------------------
    /**
     * This function is used to load the view for send_sms
     * 
     * @access		public
     * @since		1.0.0
     */
    public function send_sms() {		
		#load required model
		$this->load->model('configure_access_model', 'obj_con', TRUE);
        $data['all_data'] = $this->obj_con->get_reward_data();
		
		$this->load->view('admin/admin_header');
		$this->load->view('admin/admin_navbar');
		$this->load->view('admin/send_sms_list',$data);
		$this->load->view('admin/admin_footer');
    }
	
	//------------------------------------------------------------------------
    /*
     * This function is used to send the sms
     */
    public function send_to_sms() {
        //array to store ajax responses
        $arr_response = array('status' => ERR_DEFAULT);
		
		#load required model
		$this->load->model('configure_access_model', 'obj_con', TRUE);
        
        $return_val = $this->obj_con->send_to_sms();
		if ($return_val) {
			$arr_response['status'] = SUCCESS;
			$arr_response['message'] = 'SMS has been sent successfully';
		} else {
			$arr_response['status'] = DB_ERROR;
			$arr_response['message'] = 'Something went Wrong! Please try again';
		}
		echo json_encode($arr_response);
    }
	
	
	/*dummy function*/
	 public function dummy(){
		$arr_response = array('status' => ERR_DEFAULT);
		if (true) {
			$arr_response['status'] = SUCCESS;
			$arr_response['message'] = 'SMS has been sent successfully';
		} else {
			$arr_response['status'] = DB_ERROR;
			$arr_response['message'] = 'Something went Wrong! Please try again';
		}
		echo json_encode($arr_response);
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */