<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

			$header = array('Content-Type: multipart/form-data');
class Welcome extends CI_Controller {

	/**
	 * admin login Page for this controller.
	 */
	public function index(){
		$this->load->view('admin/admin_login');
	}
	/**
	 * admin login Page for this controller.
	 */
	public function sendsms1(){
		$this->load->view('sendsms');
	}
	
	//--------------------------------------------------------------------
    /**
     * Handles requests for checks the login credentials entered by the users.
     * 
     * @access		public
     * @since		1.0.0
     */
    public function check_login_credentials() {
        //array to store ajax responses
        $arr_response = array('status' => ERR_DEFAULT); /* 500 */
		#loading the require model
		$this->load->model('welcome_model','obj_wel',true);
		#calling the function to register a new user into the database
		$return_value = $this->obj_wel->check_login_credentials();
		if ($return_value==1) {
			$arr_response['status'] = SUCCESS; /* 200 */
			$arr_response['redirect']= 'configure_access/';
			$arr_response['message'] = 'User Credentials successfully matched.';			
		} else if ($return_value==2){
			$arr_response['status'] = DB_ERROR; /* 201 */
			$arr_response['message'] = 'Email ID not exist!';
		}else if ($return_value==3){
			$arr_response['status'] = DB_ERROR; /* 201 */
			$arr_response['message'] = 'Password is incorrect!';
		}else if ($return_value==4){
			$arr_response['status'] = DB_ERROR; /* 201 */
			$arr_response['message'] = 'Your account has been blocked !';
		}
        echo json_encode($arr_response);
    }
	
	/**
	 * reward Page for this controller.
	 */
	public function reward(){
		/*reading the user verify code from segment*/
		$verify_code = $this->uri->segment(3);
		#loading the require model
		$this->load->model('welcome_model','obj_wel',true);
		$data['reward_detail'] = $this->obj_wel->get_reward_data($verify_code);
		
		$this->load->view('save_reward',$data);
	}
	
	//-------------------------------------------------------------------------
    /*
     * This function is used to update coupon
     * 
     * @access		public
     * @since		1.0.0
     */
    public function update_reward() {
        #array to hold value to be display
        $arr_response = array();
		$this->load->model('welcome_model','obj_wel',true);

        $return_val = $this->obj_wel->update_reward();
        if ($return_val) {
            $arr_response['status'] = SUCCESS;
            $arr_response['message'] = "Reward has been submitted successfully!";
        } else {
            $arr_response['status'] = DB_ERROR;
            $arr_response['message'] = "Something went Wrong! Please try again";
        }
        echo json_encode($arr_response);
    }	
	//-------------------------------------------------------------------------
    /*
     * This function is used to update coupon
     * 
     * @access		public
     * @since		1.0.0
     */
	 
    public function get_detail_by_num() {
		$arr_response = array();
		$this->load->model('welcome_model','obj_wel',true);		
		$number = $_POST['number'];
        $return_val = $this->obj_wel->get_detail_by_num($number);
		
		if ($return_val) {
            $arr_response['status'] = SUCCESS;
            $arr_response['verify_code'] = $return_val;
        } else {
            $arr_response['status'] = DB_ERROR;
            $arr_response['message'] = "Something went Wrong! Please try again";
        }		
        echo json_encode($arr_response);
	}
	/*public function dummy() {
		echo 'dummy';
	}
    public function sendsms() {
		
		$number = $this->uri->segment(3);	
        #array to hold value to be display
        $arr_response = array();
		$this->load->model('welcome_model','obj_wel',true);
		
        $return_val = $this->obj_wel->get_detail_by_num($number);
		 
		
        if ($return_val) {
		
			$this->load->library('curl');
			$url = base_url()."welcome/sendsms1/".$number;
			//$url = "http://www.w3schools.com";
			echo $this->curl->simple_get($url);
			
            $arr_response['status'] = SUCCESS;
        } else {
			
            $arr_response['status'] = DB_ERROR;
        }
        echo json_encode($arr_response);
    }*/
	 public function put($url, $params=array()) {
		 $url = $url.'?'.http_build_query($params, '', '&');
    
		$ch = curl_init();
		
		curl_setopt($ch, CURLOPT_URL, $url);
		
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
		
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			
		$response = curl_exec($ch);
		
		curl_close($ch);
		
		return $response;
	 }
	 public function sendsms() {
		$mo = $this->uri->segment(3);
		$arr_response = array();
		$this->load->model('welcome_model','obj_wel',true);		
	  
		if(isset($mo)){
		$return_val = $this->obj_wel->get_detail_by_num($mo);			
			if ($return_val) {
				$respo = $this->put('http://login.regnantsms.com/api/web2sms.php', 
				array(
				'workingkey'=>'A5c19213e75f432b82755d98595f85310',
				'sender'=>'RBUTLR',
				'to'=>$mo,
				'message'=>'Greetings from the Samsung Business Rewards Team! Please click on the link to confirm your reward and update changes http://businessrewards.rewardbutler.com/u/i/'.$return_val)
				);
				echo json_encode(array('response'=>$respo,'status'=>'200','message'=>'message send sucessfully Send !')); 
			
			}else{
				echo json_encode(array('status'=>'201','message'=>'Invalid mobile number!')); 
			}
		}else{ 
			echo json_encode(array('status'=>'201','message'=>'Invalid mobile number!')); 				
		}
	 }
	 public function sendsms00() {
		 $arr_response = array();
		 if(isset($_POST['bar'])){
			if($_POST['bar'] == 'ok'){
				$arr_response['status'] = SUCCESS;
			}else{
				$arr_response['status'] = DB_ERROR;
			}
			echo json_encode($arr_response);
			 die();
		}else{
			$this->load->view('sendsms2');
		}
	 }
	
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */