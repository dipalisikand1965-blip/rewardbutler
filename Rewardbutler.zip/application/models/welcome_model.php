<?php

if (!defined('BASEPATH'))
    exit('Not a valid request!');

/**
 * Model Class to handle DB related operations for
 * authorization of a user.
 *
 * @version     0.0.1
 */
class Welcome_model extends CI_Model {

    /**
     * Default Constructor
     * 
     * @access  public
     * @since   0.0.1
     */
    public function __construct() {
        parent::__construct();
		date_default_timezone_set('Asia/Kolkata');
    }
	
	
	//-------------------------------------------------------------------------
    /*
     * This function is used to check availability of email etc.
     */
    public function check_availability() {
        if ($_POST['param'] == 'registration') {
            $db_result = $this->db->get_where('sante_users', array('user_email' => $_POST['user_email']));
        } else if ($_POST['param'] == 'edit_users') {
            $db_result = $this->db->get_where('sante_users', array('user_email' => $_POST['edit_user_email']));
        }
        if ($db_result && $db_result->num_rows() > 0) {
            #param already exists
            return FALSE;
        } else {
            return TRUE;
        }
    }
	
	
	//-------------------------------------------------------------------------
    /*
     * add new_user_into_database into databse
     */
    public function add_new_user() {
        date_default_timezone_set('Asia/Kolkata');
        #Generate hashed password.
        $hashed_password = sha1('admin' . (md5('admin' . $_POST['passwd'])));
		#generate random number
		$capital = implode('',range('A','Z'));
		$small = implode('',range('a','z'));
		$number = implode('',range('0','20'));
		$token = substr(str_shuffle($capital.$small.$number),40);
		
        $data = array(
            'user_email' => $_POST['user_email'],
            'firstname' => $_POST['firstname'],
            'lastname' => $_POST['lastname'],
			'user_type' => $_POST['user_type'],
            'occupation_id' => $_POST['occupation_id'],
            'password_hash' => $hashed_password,
            'created_date' => date('Y-m-d'),
            'created_time' => date('H:m:s'),
			'verify_code' => $token
        );
        $result = $this->db->insert('sante_users', $data);
		$insert_id = $this->db->insert_id();
		
        if ($insert_id) {
			/*inserting in profile table*/
			$data2 = array(
				'FK_user_id' => $insert_id,
				'date' => date('Y-m-d'),
				'time' => date('H:m:s'),
			);
			if($_POST['user_type']=="individual"){
				$result2 = $this->db->insert('sante_individual_profile', $data2);
			}else if($_POST['user_type']=="company"){
				$result2 = $this->db->insert('sante_company_profile', $data2);
			}
			#generate random number dummy use only
			$capital = implode('',range('A','Z'));
			$small = implode('',range('a','z'));
			$number = implode('',range('0','20'));
			$token_dummy = substr(str_shuffle($capital.$small.$number),40);
			#navigation_url
			$navigation_url = base_url().'configure';
			#verification link
			$verification_link = base_url().'emailClick/click_on_email_and_email_verification/confirm_user_account?a='.$_POST['user_email'].'&b='.$token_dummy.'&c='.$token.'&d=ft&e='.md5('admin' . $_POST['passwd']).'&f='.$navigation_url;
			#send a email vevrification email
			$this->load->library('email');			
			$subject = "Welcome to ".WEBSITE_NAME;
			
			$message = '<div><div style="background-color: #eee;padding: 20px;font-size: 20px;">';
			$message .= '<div style="text-align: center;    border-bottom: 1px solid;"><a href="'.WEBSITE_URL.'"><img src="'.base_url().'assets/images/'.LOGO.'" alt="'.PRODUCT_NAME.'" style="width: 100px;"></a></div><br/><br/>';
			$message .= 'Dear '.$_POST['firstname'].' '.$_POST['lastname'].',<br/><br/>';
			$message .= '<p>Thank you for registring with <a href="'.WEBSITE_URL.'">'.WEBSITE_NAME.'</a></p>';
			$message .= '<p>Please Click the button bellow to confirm your email addrss</p>';
			$message .= '<div style="text-align: center;margin: 20px;padding: 10px;"><a href="'.$verification_link.'" style="padding: 13px;background-color: blue;margin: 10px;color: #fff;font-size: 24px;">CONFIRM</a></div>';
			$message .= '<p>You may also copy and paste the link on your browser</p>';
			$message .= '<a href="'.$verification_link.'">'.$verification_link.'</a>';    
			$message .= '<br/><br/><div style="border-top: 1px solid;"><span style="font-size: 10px;">Copyright &copy; '.date("Y").' . All Rights Reserved.</span></div><br/>';
			$message .= '</div></div>';
			#print_r($message);
			$e_config = array(
				'charset'=>'utf-8',
				'wordwrap'=> TRUE,
				'mailtype' => 'html',
				'priority' => '1'
			);
			$to = $_POST['user_email'];
			$this->email->initialize($e_config);
			$this->email->from(PRODUCT_EMAIL_ID, PRODUCT_NAME);
			$this->email->to($to); 
			$this->email->subject($subject);
			$this->email->message($message);	
			$this->email->send();
            if($result2){
				return TRUE;
			}else{
				return FALSE;
			}
		} else {
            return FALSE;
        }
    }
	
	
	
    //--------------------------------------------------------------------------  
    /**
     * This function checks the login credentials entered by the users.
     * 
     * @access  public 
     * @return  boolean     TRUE if login credentials are correct otherwise FALSE
     * @since   0.0.1 
     */
    public function check_login_credentials() {
        if (empty($_POST)) {
            return FALSE;
        }
        $this->db->where('EmailID', $_POST['loginUserEmail']);
        $db_result = $this->db->get('newreward_admin_login');

        if ($db_result && $db_result->num_rows() == 1) {
            #login credentials matched
			$row = $db_result->row();
			if($row->Password!=sha1('admin' . (md5('admin' . $_POST['loginPassword'])))){
				return 3;
			}
			if($row->IsActive != 'active'){
				return 4;
			}
            #setting up the session variables
            $this->session->set_userdata(array(
                'userID' => $row->ID,
                'userEmail' => $row->EmailID,
                'userName' => $row->FirstName.' '.$row->LastName,
                'roleID' => $row->RoleID,
                'loggedIN' => 2,
            ));
            return 1;
        } else {
            #query failed or no matching values found
            return 2;
        }
    }

    
	//--------------------------------------------------------------------------  
	/*
	*To check either email exits or not.
	*
	*/
	function is_email($user_email){
		$this->db->where(array('user_email' => $user_email,'status'=>'active'));
		$res = $this->db->get('sante_users');
		if($res->num_rows() > 0){
			return $res->row_array();
		}else{
			return false;
		}
	}
	
	/*
	*To check token exists or not
	*
	*/
	function check_token($token){
		$this->db->where('verify_code',$token);
		$res = $this->db->get('newreward_reward');
		if($res->num_rows() > 0){
			return false;
		}else{
			return true;
		}
	}
	
	//--------------------------------------------------------------------------  
	/*
	*Send a email with reset link
	*
	*/
	function sentLink($user_email){
		$v_token = false;
		while($v_token != true){
			$capital = implode('',range('A','Z'));
			$small = implode('',range('a','z'));
			$number = implode('',range('0','20'));
			$token = substr(str_shuffle($capital.$small.$number),40);
			$v_token = $this->check_token($token);
		}
		$Array = array(
			'verify_code' => $token,
		);
		$this->db->set($Array);
		$this->db->where('user_email',$user_email);
		$arr_value = array();
		if($this->db->update('sante_users')){
			/*fetching the user data*/
			$user_email = trim($_POST['user_email']);
			$this->db->where(array('user_email'=>$user_email,'status'=>'active'));
			$res = $this->db->get('sante_users');
			if($res && $res->num_rows() == 1){
				
				$data = array();
				foreach ($res->result() as $row) {
					if (!array_key_exists($row->user_id, $data)) {
						$data[$row->user_id] = array();
					}
					if (array_key_exists($row->user_id, $data)) {
						$data[$row->user_id] = array(
							'user_id' => $row->user_id,
							'full_name' => $row->firstname.' '.$row->lastname,
							'user_email' => $row->user_email,
							'verify_code' => $row->verify_code,
						 );
						array_push($arr_value, $data[$row->user_id]);
					}
				}
			}
			$e = base64_encode($user_email);
			$verification_link = $token;
			$this->load->library('email');
			$to = $user_email;
			$subject = "Forget Password Request.";
			
			$message = '<div><div style="background-color: #eee;padding: 20px;font-size: 20px;">';
			$message .= '<div style="text-align: center;    border-bottom: 1px solid;"><a href="'.WEBSITE_URL.'"><img src="'.base_url().'assets/images/'.LOGO.'" alt="'.PRODUCT_NAME.'" style="width: 100px;"></a></div><br/><br/>';
			$message .= 'Dear '.$arr_value[0]['full_name'].'<br/><br/>';
			$message .= '<p>Please Click the below to change your password</p>';
			$message .= '<a href="'.base_url().'home/change_password?e='.$e.'&v='.$verification_link.'">Click Here</a>'; 
			$message .= '<br/><br/><div style="border-top: 1px solid;"><span style="font-size: 10px;">Copyright &copy; '.date("Y").' . All Rights Reserved.</span></div><br/>';
			$message .= '</div></div>';
			#print_r($message);
			$config=array(
				'charset'=>'utf-8',
				'wordwrap'=> TRUE,
				'mailtype' => 'html',
				'priority' => '1'
			);

			$this->email->initialize($config);
			$this->email->from(PRODUCT_EMAIL_ID, PRODUCT_NAME);
			$this->email->to($to); 
			$this->email->subject($subject);
			$this->email->message($message);	
			if($this->email->send()){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}
	
	
	/*
	*Updating password
	*/
	public function change_user_password(){
		$this->db->where(array('user_email'=>$_POST['user_email'],'verify_code'=>$_POST['verify_code']));
		$res = $this->db->get('sante_users');
		if($res && $res->num_rows() == 1){
			#Generate hashed password.
			$hashed_password = sha1('admin' . (md5('admin' . $_POST['new_passwd'])));
			$data = array(
				'password_hash' => $hashed_password,
			);
			$result = $this->db->update('sante_users', $data, array('user_email'=>$_POST['user_email'],'verify_code'=>$_POST['verify_code']));	
			if($this->db->affected_rows()){
				return 200;
			}else{
				return 201;
			}
		}else{
			return 204;
		}
		
		
	}
	
	
	
	
	//-------------------------------------------------------------------------
    /*
     * This function is used to update coupon
     * 
     * @access		public
     * @since		1.0.0
     */
    public function update_reward() {
		$verify_code = $_POST['verify_code'];
		
		$v_token = false;
		while($v_token != true){
			$capital = implode('',range('A','Z'));
			$small = implode('',range('a','z'));
			$number = implode('',range('0','20'));
			$token = substr(str_shuffle($capital.$small.$number),0,10);
			$v_token = $this->check_token($token);
		}
		if($verify_code == ''){
			/*$v_token = false;
			while($v_token != true){
				$capital = implode('',range('A','Z'));
				$small = implode('',range('a','z'));
				$number = implode('',range('0','20'));
				$token = substr(str_shuffle($capital.$small.$number),0,10);
				$v_token = $this->check_token($token);
			}
			$data = array(
				'reward_name' => $_POST['reward_name'],
				'address' => $_POST['address'],
				'address1' => $_POST['address1'],
				'mobile_no' => $_POST['mobile_no'],
				'reward' => $_POST['reward'],
				'verify_code' => $token,
				'date' => date('Y-m-d'),
				'time' => date('H:m:s'),
			);
			$result = $this->db->insert('newreward_reward', $data);      
			if ($this->db->affected_rows()) {
				return TRUE;
			} else {
				return FALSE;
			}*/
			return FALSE;
		}else{
			$data = array(
				'reward_name' => $_POST['reward_name'],
				'reward_namef' => $_POST['reward_namef'],
				'EmailId' => $_POST['EmailId'],
				'address' => $_POST['address'],
				'address1' => $_POST['address1'],
				'mobile_no' => $_POST['mobile_no'],
				'LandMark' => $_POST['LandMark'],
				'Pincode' => $_POST['Pincode'],
				'State' => $_POST['State'],
				'City' => $_POST['City'],
				'reward' => $_POST['reward'],
				'Opted' => $_POST['Opted'],
				'verify_code' => $token,
				'is_updated' => 1,
			);
			$result = $this->db->update('newreward_reward', $data, array('verify_code' => $verify_code));      
			if ($this->db->affected_rows()) {
				return TRUE;
			} else {
				return FALSE;
			}
		}  	
	}
	
	//-------------------------------------------------------------------------
    /*
     * This function is used to get city list
     */
    public function get_reward_data($verify_code='') {
		if($verify_code==''){
			return false;
		}
		$db_result = $this->db->get_where('newreward_reward', array('status' => 'active','verify_code'=> $verify_code));
        if ($db_result && $db_result->num_rows() > 0) {
            $data = array();
            $data_value = array();
            foreach ($db_result->result() as $row) {
                if (!array_key_exists($row->reward_id, $data)) {
                    $data[$row->reward_id] = array();
                }
                if (array_key_exists($row->reward_id, $data)) {
                    $data[$row->reward_id] = array(
                        'reward_id' => $row->reward_id,
                        'DMSCode' => $row->DMSCode,
                        'EmailId' => $row->EmailId,
						'reward_name' => $row->reward_name,
						'reward_namef' => $row->reward_namef,
						'mobile_no' => $row->mobile_no,
						'address' => $row->address,
						'address1' => $row->address1,
						'LandMark' => $row->LandMark,
						'Pincode' => $row->Pincode,
						'State' => $row->State,
						'City' => $row->City,
						'reward' => $row->reward,
						'Opted' => $row->Opted,
						'verify_code' => $row->verify_code,
						'date'=> $row->date,
                    );
                    array_push($data_value, $data[$row->reward_id]);
                }
            }
            return $data_value;
        } else {
            return FALSE;
        }
    }
	
		
	//-------------------------------------------------------------------------
    /*
     * This function is used to get city list
     */
    public function get_detail_by_num($number) {
		
		$db_result = $this->db->get_where('newreward_reward', array('status' => 'active','mobile_no'=> $number));
        if ($db_result && $db_result->num_rows() > 0) {
            $data = array();
            $data_value = array();
			$verify_code = '';
            foreach ($db_result->result() as $row) {
                if (!array_key_exists($row->reward_id, $data)) {
                    $data[$row->reward_id] = array();
                }
                if (array_key_exists($row->reward_id, $data)) {
                    $data[$row->reward_id] = array(
                        'reward_id' => $row->reward_id,
                        'DMSCode' => $row->DMSCode,
                        'verify_code' => $row->verify_code,
                    );
					$verify_code = $row->verify_code;
                    array_push($data_value, $data[$row->reward_id]);
                }
            }
            return $verify_code;
        } else {
            return FALSE;
        }
    }
	
	

}

//End of class Authorization_model

//End of file authorization_model.php
/* Location: ../../models/authorization/authorization_model.php */