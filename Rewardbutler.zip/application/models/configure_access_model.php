<?php

if (!defined('BASEPATH'))
    exit('Not A Valid Request');

class Configure_access_model extends CI_Model {
	
    public function __construct() {
        parent::__construct();
        $this->load->helper('string');
		date_default_timezone_set('Asia/Kolkata');
    }
	
	
	//-------------------------------------------------------------------------
    /*
     * This function is used to to update password.
     */
    public function update_password() {
        #check user exists or not
        $db_result = $this->db->get_where('newreward_admin_login', array('ID' => $this->session->userdata('userID')));
        if ($db_result && $db_result->num_rows() == 1) {
            #user exists
            #check old password is same or not
            $old_hashed_password = sha1('admin' . (md5('admin' . $_POST['old_password'])));
			$row = $db_result->result();
            if ($old_hashed_password == $row[0]->Password) {
                #update pssword
                $data = array(
                    'Password' => sha1('admin' . (md5('admin' . $_POST['new_password'])))
                );
                $this->db->update('newreward_admin_login', $data, array('ID' => $this->session->userdata('userID')));
				if ($this->db->affected_rows() > 0) {
					return 1;
				}else {
					return FALSE;
				}
			}else {
				return 2;
			}
		}
    }
	
	/*
	*To check token exists or not
	*
	*/
	function check_token($token){
		$this->db->where('verify_code',$token);
		$res = $this->db->get('newreward_reward');
		if($res->num_rows() > 0){
			return false;
		}else{
			return true;
		}
	}
	
	function clean($string) {
	   $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.
	   $string = preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.

	   return preg_replace('/-+/', ' ', $string); // Replaces multiple hyphens with single one.
	}
	
	//-------------------------------------------------------------------------
    /*
     * This function is used to read_csv
     */
    public function read_csv() {
         $this->load->library('csvimport');
        $csv = new csvimport();
        $csv_array = $csv->get_array('uploads/'.$_POST['filename']);
        foreach ($csv_array as $key => $value) {
            $v_token = false;
			while($v_token != true){
				$capital = implode('',range('A','Z'));
				$small = implode('',range('a','z'));
				$number = implode('',range('0','20'));
				$token = substr(str_shuffle($capital.$small.$number),0,10);
				$v_token = $this->check_token($token);
			}
			$data = array(
				'DMSCode' => $value['DMSCode'],
				'EmailId' => $value['EmailId'],
				'reward_name' => $value['FirstName'],
				'reward_namef' => $value['LastName'],
				'mobile_no' => $value['Mobile'],
				'LandMark' => str_replace(',', ' ', ($value['LandMark'])),
				'Pincode' => $value['Pincode'],
				'State' => str_replace(',', ' ', ($value['State'])),
				'City' => str_replace(',', ' ', ($value['City'])),
				'reward' => $value['RewardName'],
				'Opted' => $value['Opted'],
				'verify_code' => $token,
				'date' => date('Y-m-d'),
				'time' => date('H:m:s'),
				'address' => str_replace(',', ' ', ($value['Address1']) ),
				'address1' => str_replace(',', ' ', ($value['Address2'])),
			);
			
			$this->db->where(array('EmailId'=>$value['EmailId']));
			#$this->db->where(array('DMSCode'=>$value['DMSCode']));
			$db_result = $this->db->get('newreward_reward');
			if($db_result && $db_result->num_rows()>0){
				$row = $db_result->row();
				$reward_id = $row->reward_id;
				$db_result = $this->db->update('newreward_reward',$data,array('reward_id'=>$reward_id));
			}else{
				$db_result = $this->db->insert('newreward_reward',$data);
			}
		}
		if($db_result){
			return true;
		}else{
			return false;
		}
        
    }
	
	
	//-------------------------------------------------------------------------
    /*
     * This function is used to get city list
     */
    public function get_reward_data($is_updated = 0) {
		if($is_updated!=0){
			$this->db->where(array('is_updated' => 1));
		}
		$db_result = $this->db->get('newreward_reward');
        if ($db_result && $db_result->num_rows() > 0) {
            $data = array();
            $data_value = array();
            foreach ($db_result->result() as $row) {
                if (!array_key_exists($row->reward_id, $data)) {
                    $data[$row->reward_id] = array();
                }
                if (array_key_exists($row->reward_id, $data)) {
                    $data[$row->reward_id] = array(
                        'reward_id' => $row->reward_id,
                        'DMSCode' => $row->DMSCode,
                        'EmailId' => $row->EmailId,
						'reward_name' => $row->reward_name,
						'reward_namef' => $row->reward_namef,
						'mobile_no' => $row->mobile_no,
						'address' => $row->address,
						'address1' => $row->address1,
						'LandMark' => $row->LandMark,
						'Pincode' => $row->Pincode,
						'State' => $row->State,
						'City' => $row->City,
						'reward' => $row->reward,
						'Opted' => $row->Opted,
						'verify_code' => $row->verify_code,
						'is_updated' => $row->is_updated,
						'date'=> $row->date,
                    );
                    array_push($data_value, $data[$row->reward_id]);
                }
            }
            return $data_value;
        } else {
            return FALSE;
        }
    }
	
	//-------------------------------------------------------------------------
    /*
     * This function is used to read_csv
     */
    public function send_to_sms() {
			$data = array(
				'sms_sent' => 1,
				'sms_sent_date' => date('Y-m-d'),
			);
			$db_result = $this->db->update('newreward_reward',$data,array('reward_id'=>$_POST['reward_id']));
		
		if($this->db->affected_rows()>0){
			return true;
		}else{
			return false;
		}
        
    }
	
	
}
