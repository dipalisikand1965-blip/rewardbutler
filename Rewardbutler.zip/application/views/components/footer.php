
        <div class="copyright"> <?php echo date('Y');?> ©  <?php echo PROJECT_NAME;?></div>
        <!--[if lt IE 9]>
		<script src="../assets/global/plugins/respond.min.js"></script>
		<script src="../assets/global/plugins/excanvas.min.js"></script> 
		<![endif]-->
        
    </body>

</html>