<!DOCTYPE html>
<html lang="en">
    <head>
        

<!-- Bootstrap -->
<link href="<?php echo base_url();?>assets/css/plugins/bootstrap.css" rel="stylesheet">
<!--=== Add By Designer ===-->


<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/jquery-2.1.1.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="<?php echo base_url();?>assets/js/plugins/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets/js/plugins/jquery.form.min.js"></script>
<script src="<?php echo base_url();?>assets/js/plugins/jquery.blockui.min.js"></script>
<script src="<?php echo base_url();?>assets/js/plugins/jquery.validate.min.js"></script>
<!--script href="<?php echo base_url();?>assets/js/plugins/jquery.blockui.min.js"></script-->
<script src="<?php echo base_url();?>assets/js/constant.js"></script>

<div class="container response" style="margin-top:20px;">

</div>
<script>
$('document').ready(function(){
	$.blockUI();
	var url = window.location.href;
	var number_ = url.split('sendsms/')[1];
	var number = number_.split('/')[0];
	$.post(APP_URL+'welcome/get_detail_by_num',{
		number : number,
	},function(response){
		$('#headerMsg2').empty();
		if (response.status == 200) {
			console.log(response.data_value[0]['verify_code']);
			var url = "http://login.regnantsms.com/api/web2sms.php?workingkey=A5c19213e75f432b82755d98595f85310&sender=RBUTLR&to="+number+"&message=Greetings from the Samsung Business Rewards Team! Please click on the link to confirm your reward and update changes http://businessrewards.rewardbutler.com/u/i/"+response.data_value[0]['verify_code'];
			$.ajax({
				url: url,
				type: 'GET',
				async: false,
				dataType: 'jsonp',
				crossDomain : true,
				success: function(result){
					var content = '{status: "200",message:"Message has been sent successfully!"}';
					$('.response').empty();
					$('.response').html(content);
					alert('Message sent successfully');	$.unblockUI();				
				},
				error: function(result){
					var content = '{status: "200",message:"Message has been sent successfully!"}';
					$('.response').empty();
					$('.response').html(content);
					alert('Message sent successfully');	$.unblockUI();
				},
			});
		}else{
			var content = '{status: "201",message:"This mobile Number is not exist!!!"}';
			$('.response').empty();
			$('.response').html(content);
			alert('This mobile Number is not exist!!!');$.unblockUI();
		}
	},'json');
	$.unblockUI();
});

</script>
</head>
<body>


</body>
</html>