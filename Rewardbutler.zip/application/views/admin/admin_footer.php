
		
		<div class="page-footer">
            <div class="page-footer-inner"> <?php echo date('Y');?> ©  <?php echo PROJECT_NAME;?>
                
            </div>
            <div class="scroll-to-top">
                <i class="icon-arrow-up"></i>
            </div>
        </div>
        <!--[if lt IE 9]>
<script src="../assets/global/plugins/respond.min.js"></script>
<script src="../assets/global/plugins/excanvas.min.js"></script> 
<![endif]-->
        <!-- BEGIN CORE PLUGINS -->
        
        <script src="<?php echo base_url();?>assets/pages/scripts/login.js" type="text/javascript"></script>
    </body>

</html>