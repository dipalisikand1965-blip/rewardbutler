<script src="<?php echo base_url(); ?>assets/js/plugins/jquery.dataTables.min.js"></script> 
<link href="<?php echo base_url(); ?>assets/css/plugins/jquery.dataTables.min.css" rel="stylesheet">

<link href="<?php echo base_url();?>assets/css/plugins/uploader.css" rel="stylesheet">
<link href="<?php echo base_url();?>assets/css/plugins/demo.css" rel="stylesheet">
<script src="<?php echo base_url(); ?>assets/js/plugins/demo.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/plugins/dmuploader.min.js"></script>

<style>
.form-group {
	margin-bottom: 5px;
	margin-top: 10px;
}
.error{
	color:red;
}
.form-actions {
    padding: 17px 20px 18px;
    margin-top: 18px;
    margin-bottom: 18px;
    background-color: #f5f5f5;
    border-top: 1px solid #e5e5e5;
}	
</style>
		
            <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    
                    <!-- BEGIN PAGE BREADCRUMB -->
                    <ul class="page-breadcrumb breadcrumb">
                        <li>
                            <a href="<?php echo base_url();?>configure_access">Home</a>
                            <i class="fa fa-circle"></i>
                        </li>
                        <li>
                            <span class="active"> Upload CSV</span>
                        </li>
                    </ul>
                    <!-- END PAGE BREADCRUMB -->
                    <!-- BEGIN PAGE BASE CONTENT -->
                    <div class="row">
						<div class="col-md-12">
							<div class="portlet light">
								<div class="panel panel-default">
									<div class="panel-heading">
										<h3 class="panel-title"><i class="fa fa-edit"></i> Upload CSV</h3>
									</div>
									<div class="panel-body">
										<div class="row">
											<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
												<div class="widget-container fluid-height clearfix"><br/>
													<div id="err_change_password_form"></div>
													<div class="widget-content padded outer_wrapper">
														<form id="change_password_form" method="post" class="form-horizontal" style="margin-bottom:50px;">
															<div class="form-group">
																<label class="control-label col-md-2" for="old_password"><span class="required">* </span>Upload CSV</label>
																<div class="col-md-5">
																	<button type="button" class="btn btn-info" data-toggle="modal" data-target="#browseCsv">Upload CSV File</button>
																</div>
															</div>
														</form>
														
													</div>
												</div>
											</div>
										</div>
									
									</div>
								</div>
							</div>
						</div>
					
					</div>                    
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->
            <!-- BEGIN QUICK SIDEBAR -->
            <a href="javascript:;" class="page-quick-sidebar-toggler">
                <i class="icon-login"></i>
            </a>
        </div>
        <!-- END CONTAINER -->
<!---------------------------- Modal for Browse Image-------------------------->
<div class="modal fade" id="browseCsv" tabindex="-1" course_package="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h3>Browse CSV</h3>
            </div>
			<div class="modal-body">
				<div id="head1_msg"></div>
				<input type="hidden" value="csv" name="image_profile" class="image_profile">
				<div class="row demo-columns">
					<div class="col-md-8 col-md-offset-2">
						<p>Maximum rows in table file is 10</p>
						<!-- D&D Zone-->
						<div id="uploade_file" class="uploader">
							<div>Drag &amp; Drop File Here</div>
							<div class="or">-or-</div>
							<div class="browser">
								<label>
									<span>Click to open the file Browser</span>
									<input type="file" name="files[]" multiple="multiple" title='Click to add Files'>
								</label>
							</div>
						</div>
						<!-- /D&D Zone -->
						<!-- Debug box -->
						<div class="panel panel-default display_none">
							<div class="panel-heading">
								<h3 class="panel-title">Debug</h3>
							</div>
							<div class="panel-body demo-panel-debug">
								<ul id="demo-debug">
								</ul>
							</div>
						</div>
						<!-- /Debug box -->
					</div>
					<div class="clearfix"></div>
					<!-- / Left column -->
					<div class="col-md-8 col-md-offset-2">
						<div class="panel panel-default">
							<div class="panel-heading">
								<h3 class="panel-title">Uploads</h3>
							</div>
							<div class="panel-body demo-panel-files minHeight" id='demo-files'>
								<span class="demo-note">No Files have been selected/droped yet...</span>
							</div>
						</div>
					</div>
					<!-- / Right column -->
				</div>
			</div><!-- / modal-body -->
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
	   
        </div>
    </div>
</div>		
		
<script>
$(document).ready(function () {
	
	//-------------------------------------------------------------------
	/*uploading drag and drop image*/
	$('#uploade_file').dmUploader({
        url: APP_URL+'configure_access/upload_csvFile',
        dataType: 'json',
		extraData: {
		  image_profile: $('#browseCsv').find('.image_profile').val(),
		},
		maxFiles :'1',
		fileName : 'myFile',
		//maxFileSize :'1',
        //allowedTypes: 'image/*',
        /*extFilter: 'jpg;png;gif',*/
        onInit: function(){
          $.danidemo.addLog('#demo-debug', 'default', 'Plugin initialized correctly');
        },
        onBeforeUpload: function(id){
          
		  $.danidemo.addLog('#demo-debug', 'default', 'Starting the upload of #' + id);

          $.danidemo.updateFileStatus(id, 'default', 'Uploading...');
        },
        onNewFile: function(id, file){
			$('.demo-panel-files').empty();
			$.danidemo.addFile('#demo-files', id, file);
        },
        onComplete: function(){
          
		  $.danidemo.addLog('#demo-debug', 'default', 'All pending tranfers completed');
        },
        onUploadProgress: function(id, percent){
          var percentStr = percent + '%';

          $.danidemo.updateFileProgress(id, percentStr);
        },
        onUploadSuccess: function(id, data){
			var status= data.status;
			var filename_ = data.filename;
			if(status == 200){
				$('#browseCsv').modal('hide');
				//$.blockUI();
				$.post(APP_URL+'configure_access/html_parser_csv_file',{
					filename : filename_,
				},function(response){
					$.unblockUI();
					if(response.status == 200){
						
						alert(response.message);
					}else{
						alert(response.message);
					}
				},'json');
				
				$("#myFile").val('');
			}else{
                $('#browseCsv').modal('hide');
                alert(data.message);
			}
			
		  $.danidemo.addLog('#demo-debug', 'success', 'Upload of file #' + id + ' completed');

          $.danidemo.addLog('#demo-debug', 'info', 'Server Response for file #' + id + ': ' + JSON.stringify(data));

          $.danidemo.updateFileStatus(id, 'success', 'Upload Complete');

          $.danidemo.updateFileProgress(id, '100%');
			$('.demo-panel-files').empty();
			var content = '<span class="demo-note">No Files have been selected/droped yet...</span>';
			$('.demo-panel-files').html(content);
		},
        onUploadError: function(id, message){
			alert(message);
          $.danidemo.updateFileStatus(id, 'error', message);

          $.danidemo.addLog('#demo-debug', 'error', 'Failed to Upload file #' + id + ': ' + message);
        },
        onFileTypeError: function(file){
			alert('File \'' + file.name + '\' cannot be added: must be an image');
			$.danidemo.addLog('#demo-debug', 'error', 'File \'' + file.name + '\' cannot be added: must be an image');
        },
        onFileSizeError: function(file){
			alert('File \'' + file.name + '\' cannot be added: size excess limit');
			$.danidemo.addLog('#demo-debug', 'error', 'File \'' + file.name + '\' cannot be added: size excess limit');
        },
        /*onFileExtError: function(file){
          $.danidemo.addLog('#demo-debug', 'error', 'File \'' + file.name + '\' has a Not Allowed Extension');
        },*/
        onFallbackMode: function(message){
			alert('info', 'Browser not supported(do something else here!): ' + message);
          $.danidemo.addLog('#demo-debug', 'info', 'Browser not supported(do something else here!): ' + message);
        },
		onFilesMaxError: function(file){
			alert(' cannot be added to queue due to upload limits.');
		  $.danidemo.addLog(file.name + ' cannot be added to queue due to upload limits.');
		}
    });
		

});

</script>		