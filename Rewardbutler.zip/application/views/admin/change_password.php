<style>
.form-group {
	margin-bottom: 5px;
	margin-top: 10px;
}
.error{
	color:red;
}
.form-actions {
    padding: 17px 20px 18px;
    margin-top: 18px;
    margin-bottom: 18px;
    background-color: #f5f5f5;
    border-top: 1px solid #e5e5e5;
}	
</style>
		
            <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    
                    <!-- BEGIN PAGE BREADCRUMB -->
                    <ul class="page-breadcrumb breadcrumb">
                        <li>
                            <a href="<?php echo base_url();?>configure_access">Home</a>
                            <i class="fa fa-circle"></i>
                        </li>
                        <li>
                            <span class="active">Change Password</span>
                        </li>
                    </ul>
                    <!-- END PAGE BREADCRUMB -->
                    <!-- BEGIN PAGE BASE CONTENT -->
                    <div class="row">
						<div class="col-md-12">
							<div class="portlet light">
								<div class="panel panel-default">
									<div class="panel-heading">
										<h3 class="panel-title"><i class="fa fa-edit"></i> Change Password</h3>
									</div>
									<div class="panel-body">
										<div class="row">
											<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
												<div class="widget-container fluid-height clearfix"><br/>
													<div id="err_change_password_form"></div>
													<div class="widget-content padded outer_wrapper">
														<form id="change_password_form" method="post" class="form-horizontal">

															<input type="hidden" value="" id="current_user_id" name="current_user_id"/>

															<div class="form-group">
																<label class="control-label col-md-2" for="old_password"><span class="required">* </span>Old Password</label>
																<div class="col-md-5">
																	<input class="form-control no_blank" id="old_password" name="old_password" placeholder="Old Password" type="password">
																</div>
															</div>
															<label for="old_password" class="error col-md-offset-2" generated="true"></label>
															<div id="err_old_password" class="col-md-offset-2"></div>

															<div class="form-group">
																<label class="control-label col-md-2" for="new_password"><span class="required">* </span>New Password</label>
																<div class="col-md-5">
																	<input class="form-control no_blank" id="new_password" name="new_password" placeholder="New Password" type="password">
																</div>
															</div>
															<label for="new_password" class="error col-md-offset-2" generated="true"></label>
															<div id="err_new_password" class="col-md-offset-2"></div>

															<div class="form-group">
																<label class="control-label col-md-2" for="confirm_password"><span class="required">* </span>Confirm Password</label>
																<div class="col-md-5">
																	<input class="form-control no_blank" id="confirm_password" name="confirm_password" placeholder="Confirm Password" type="password">
																</div>
															</div>
															<label for="confirm_password" class="error col-md-offset-2" generated="true"></label>
															<div id="err_confirm_password" class="col-md-offset-2"></div>

															<div class="form-group form-actions">
																<div class="col-md-5 col-md-offset-2">
																	<input class="btn btn-primary" type="submit" value="Submit">  
																	&nbsp;&nbsp;<input class="btn btn-primary" type="reset" value="Clear">  
																</div>                            
															</div>                            
														</form>
														
													</div>
												</div>
											</div>
										</div>
									
									</div>
								</div>
							</div>
						</div>
					
					</div>                    
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->
            <!-- BEGIN QUICK SIDEBAR -->
            <a href="javascript:;" class="page-quick-sidebar-toggler">
                <i class="icon-login"></i>
            </a>
        </div>
        <!-- END CONTAINER -->
		
<script>
$(document).ready(function () {
	//-----------------------------------------------------------------------
    /* 
     * admin_add_new_user_form validation
     */
    $('#change_password_form').validate({
        rules: {
            old_password: {
                required: true
            },
            new_password: {
                required: true,
                minlength: 6,
            },
            confirm_password: {
                required: true,
                equalTo: "#new_password"
            }

        },
        messages: {
            old_password: {
                required: "Old Password is required"
            },
            new_password: {
                required: "New Password is required",
                minlength: "Atleast 6 character Required",
                pwcheck: "Atleast One lower case Character." + '<br/>' + "Atleast One Upper case Character." + '<br/>' + "Atleast One Digit" + '<br/>' + "Contain any one of thses !\-@._*"
            },
            confirm_password: {
                required: "Confirm Password is required",
                equalTo: "Confirm Password should be same as New Password"
            }
        },
        submitHandler: function (form) {
            var old_password = $('#old_password').val();
            var new_password = $('#new_password').val();

            $.post(APP_URL + 'configure_access/update_password', {
                old_password: old_password,
                new_password: new_password
            },
            function (response) {
                $('#err_change_password_form').empty();
                if (response.status == 200) {
                    $('#err_change_password_form').empty();
                    $('#err_change_password_form').html("<div class='alert alert-success fade in'>\n\<button class='close' type='button' data-dismiss='alert'>x</button>\n\<strong>" + response.message + "</strong></div>");
                }
                else {
                    $('#err_change_password_form').empty();
                    $('#err_change_password_form').html("<div class='alert alert-danger fade in'>\n\<button class='close' type='button' data-dismiss='alert'>x</button>\n\<strong>" + response.message + "</strong></div>");
                }
				
				$('#old_password').val('');
                $('#new_password').val('');
				$('#confirm_password').val('');
            }, 'json');
            return false;
        }
    });
});

</script>		