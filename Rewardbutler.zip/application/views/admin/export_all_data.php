<script src="<?php echo base_url(); ?>assets/js/plugins/jquery.dataTables.min.js"></script> 
<link href="<?php echo base_url(); ?>assets/css/plugins/jquery.dataTables.min.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/css/plugins/dataTables.tableTools.css" rel="stylesheet">
<script src="<?php echo base_url(); ?>assets/js/plugins/dataTables.tableTools.js"></script>

<script>
    $(function() {
        var oTable = $('#admin_table').dataTable({
			"dom": 'T<"clear">lfrtip',
			"tableTools": {
				"sSwfPath": "../assets/js/swf/copy_csv_xls_pdf.swf"
			},
			buttons: [
				'csv', 'excel'
			],
			"aLengthMenu": [[10, 25, 50, 75, -1], [10, 25, 50, 75, "All"]],
			"iDisplayLength": 25
		});
    });
</script>
<style>
.img-preview{width: 80px;height: 80px;}
.form-group {
	margin-bottom: 5px;
	margin-top: 10px;
}
.error{
	color:red;
}
.form-actions {
    padding: 17px 20px 18px;
    margin-top: 18px;
    margin-bottom: 18px;
    background-color: #f5f5f5;
    border-top: 1px solid #e5e5e5;
}
th,td{
	text-align:center;
}
.display_none{
	display:none;
}	
.table_img{width:50px;height"50px;}
</style>
		
            <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    
                    <!-- BEGIN PAGE BREADCRUMB -->
                    <ul class="page-breadcrumb breadcrumb">
                        <li>
                            <a href="<?php echo base_url();?>configure_access">Home</a>
                            <i class="fa fa-circle"></i>
                        </li>
                        <li>
                            <span class="active">Export All</span>
                        </li>
                    </ul>
                    <!-- END PAGE BREADCRUMB -->
                    <!-- BEGIN PAGE BASE CONTENT -->
                    <div class="row">
						<div class="col-md-12">
							<div class="portlet light">
								<div class="panel panel-default view_panel">
									<div class="panel-heading">
										<h3 class="panel-title"><i class="fa fa-user"></i> Export All <a href="javascript:void(0);" class="pull-right add_new add_item" ></a></h3>
									</div>
									<div class="panel-body">
										<div class="row">
											<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 view_item">
												<div class="widget-container fluid-height clearfix"><br/>
													<div id="headerMsg2" class="error_msg"></div>
													
													<div id="table_view" class="table-responsive">  								
														<table id="admin_table" class="table table-striped table-hover table-bordered">
															<thead>
																<tr>
																	<th>S.No.</th>
																	<th>DMSCode</th>
																	<th>First Name</th>
																	<th>Last Name</th>
																	<th>Verified</th>
																	<th>EmailId</th>
																	<th>Mobile Number</th>
																	<th>Address1</th>
																	<th>Address2</th>
																	<th>LandMark</th>
																	<th>Pincode</th>
																	<th>State</th>
																	<th>City</th>
																	<th>Security Key</th>
																	<th>Reward</th>
																	<th>Opted</th>
																</tr>
															</thead>
															<tbody>
																<?php
																	if($csv_data){
																		$content = '';
																		$i=1;
																		foreach($csv_data as $csv){
																			$content .= '<tr>';
																			$content .= '<td>'.$i.'</td>';
																			$content .= '<td>'.$csv['DMSCode'].'</td>';
																			$content .= '<td>'.$csv['reward_name'].'</td>';
																			$content .= '<td>'.$csv['reward_namef'].'</td>';
																			$is_updated = 'No';
																			if($csv['is_updated']){
																				$is_updated = 'Yes';
																			}
																			$content .= '<td>'.$is_updated.'</td>';
																			$content .= '<td>'.$csv['EmailId'].'</td>';
																			$content .= '<td>'.$csv['mobile_no'].'</td>';
																			$content .= '<td>'.$csv['address'].'</td>';
																			$content .= '<td>'.$csv['address1'].'</td>';
																			$content .= '<td>'.$csv['LandMark'].'</td>';
																			$content .= '<td>'.$csv['Pincode'].'</td>';
																			$content .= '<td>'.$csv['State'].'</td>';
																			$content .= '<td>'.$csv['City'].'</td>';
																			$content .= '<td>'.$csv['verify_code'].'</td>';
																			$content .= '<td>'.$csv['reward'].'</td>';
																			$content .= '<td>'.$csv['Opted'].'</td>';
																			$content .= '</tr>';
																			$i++;
																		}
																		echo $content;
																	}
																?>
															
															</tbody>
														</table>
													</div>
												</div>
											</div>
						
											</div>
										</div>
									</div>
								</div>
							</div>
								
						</div>
					</div>
					
					</div>                    
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->
            
        </div>
        <!-- END CONTAINER -->
<!---------------------------- Modal for Browse Image-------------------------->
<div class="modal fade" id="browseImage" tabindex="-1" course_package="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h3>Browse Image</h3>
            </div>
			<div class="modal-body">
				<div id="head1_msg"></div>
				<input type="hidden" value="user_pic" name="image_profile" class="image_profile">
				<div class="row demo-columns">
					<div class="col-md-8 col-md-offset-2">
						<p>Image type should be GIF,JPG,PNG</p>
						<p>Image should be 2 MB or smaller</p>
						<!-- D&D Zone-->
						<div id="drag-and-drop-zone" class="uploader">
							<div>Drag &amp; Drop Images Here</div>
							<div class="or">-or-</div>
							<div class="browser">
								<label>
									<span>Click to open the file Browser</span>
									<input type="file" name="files[]" multiple="multiple" title='Click to add Files'>
								</label>
							</div>
						</div>
						<!-- /D&D Zone -->
						<!-- Debug box -->
						<div class="panel panel-default display_none">
							<div class="panel-heading">
								<h3 class="panel-title">Debug</h3>
							</div>
							<div class="panel-body demo-panel-debug">
								<ul id="demo-debug">
								</ul>
							</div>
						</div>
						<!-- /Debug box -->
					</div>
					<div class="clearfix"></div>
					<!-- / Left column -->
					<div class="col-md-8 col-md-offset-2">
						<div class="panel panel-default">
							<div class="panel-heading">
								<h3 class="panel-title">Uploads</h3>
							</div>
							<div class="panel-body demo-panel-files minHeight" id='demo-files'>
								<span class="demo-note">No Files have been selected/droped yet...</span>
							</div>
						</div>
					</div>
					<!-- / Right column -->
				</div>
			</div><!-- / modal-body -->
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
	   
        </div>
    </div>
</div>		


<!---------------------------- Modal for Browse Image-------------------------->
<div class="modal fade" id="browseCsv" tabindex="-1" course_package="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h3>Browse CSV</h3>
            </div>
			<div class="modal-body">
				<div id="head1_msg"></div>
				<input type="hidden" value="csv" name="image_profile" class="image_profile">
				<div class="row demo-columns">
					<div class="col-md-8 col-md-offset-2">
						<p>Maximum rows in table file is 10</p>
						<!-- D&D Zone-->
						<div id="uploade_file" class="uploader">
							<div>Drag &amp; Drop File Here</div>
							<div class="or">-or-</div>
							<div class="browser">
								<label>
									<span>Click to open the file Browser</span>
									<input type="file" name="files[]" multiple="multiple" title='Click to add Files'>
								</label>
							</div>
						</div>
						<!-- /D&D Zone -->
						<!-- Debug box -->
						<div class="panel panel-default display_none">
							<div class="panel-heading">
								<h3 class="panel-title">Debug</h3>
							</div>
							<div class="panel-body demo-panel-debug">
								<ul id="demo-debug">
								</ul>
							</div>
						</div>
						<!-- /Debug box -->
					</div>
					<div class="clearfix"></div>
					<!-- / Left column -->
					<div class="col-md-8 col-md-offset-2">
						<div class="panel panel-default">
							<div class="panel-heading">
								<h3 class="panel-title">Uploads</h3>
							</div>
							<div class="panel-body demo-panel-files minHeight" id='demo-files'>
								<span class="demo-note">No Files have been selected/droped yet...</span>
							</div>
						</div>
					</div>
					<!-- / Right column -->
				</div>
			</div><!-- / modal-body -->
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
	   
        </div>
    </div>
</div>		
			