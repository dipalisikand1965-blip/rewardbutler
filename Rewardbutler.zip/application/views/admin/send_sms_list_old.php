<script src="<?php echo base_url(); ?>assets/js/plugins/jquery.dataTables.min.js"></script> 
<link href="<?php echo base_url(); ?>assets/css/plugins/jquery.dataTables.min.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/css/plugins/dataTables.tableTools.css" rel="stylesheet">
<script src="<?php echo base_url(); ?>assets/js/plugins/dataTables.tableTools.js"></script>

<script src="<?php echo base_url(); ?>assets/js/admin/manageUser.js"></script> 
<script>
    $(function() {
        var oTable = $('#admin_table').dataTable({
			"aLengthMenu": [[10, 25, 50, 75, -1], [10, 25, 50, 75, "All"]],
			"iDisplayLength": 25
		});
    });
</script>
<style>
.img-preview{width: 80px;height: 80px;}
.form-group {
	margin-bottom: 5px;
	margin-top: 10px;
}
.error{
	color:red;
}
.form-actions {
    padding: 17px 20px 18px;
    margin-top: 18px;
    margin-bottom: 18px;
    background-color: #f5f5f5;
    border-top: 1px solid #e5e5e5;
}
th,td{
	text-align:center;
}
.display_none{
	display:none;
}	
.table_img{width:50px;height"50px;}
</style>
		
            <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    
                    <!-- BEGIN PAGE BREADCRUMB -->
                    <ul class="page-breadcrumb breadcrumb">
                        <li>
                            <a href="<?php echo base_url();?>configure_access">Home</a>
                            <i class="fa fa-circle"></i>
                        </li>
                        <li>
                            <span class="active">Send SMS</span>
                        </li>
                    </ul>
                    <!-- END PAGE BREADCRUMB -->
                    <!-- BEGIN PAGE BASE CONTENT -->
                    <div class="row">
						<div class="col-md-12">
							<div class="portlet light">
								<div class="panel panel-default view_panel">
									<div class="panel-heading">
										<h3 class="panel-title"><i class="fa fa-user"></i> Send SMS <a href="javascript:void(0);" class="pull-right add_new add_item" ></a></h3>
									</div>
									<div class="panel-body">
										<div class="row">
											<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 view_item">
												<div class="widget-container fluid-height clearfix"><br/>
													<div id="headerMsg2" class="error_msg"></div>
													<div class="text-center">
														<label class="radio-inline">
															<input type="radio" name="checked_unchecked_all" class="checked_unchecked_all" value="checked">Checked All
														</label>
														<label class="radio-inline">
															<input type="radio" name="checked_unchecked_all" class="checked_unchecked_all" value="unchecked">Unchecked All
														</label>
													</div>
													
													<div id="table_view" class="table-responsive">  								
														<table id="admin_table" class="table table-striped table-hover table-bordered">
															<thead>
																<tr>
																	<th>S.No.</th>
																	<th>DMSCode</th>
																	<th>Name</th>
																	<th>EmailId</th>
																	<th>Mobile Number</th>
																	<th>Address1</th>
																	<th>Address2</th>
																	<th>LandMark</th>
																	<th>Pincode</th>
																	<th>State</th>
																	<th>City</th>
																	<th>Security Key</th>
																	<th>Reward</th>
																	
																</tr>
															</thead>
															<tbody>
																<?php
																	if($all_data){
																		$content = '';
																		$i=1;
																		foreach($all_data as $csv){
																			$content .= '<tr>';
																			$content .= '<td class="checkbox"><label><input type="checkbox" name="select_mem" class="select_mem" value="'.$csv['reward_id'].'" mobile="'.$csv['mobile_no'].'" security_key="'.$csv['verify_code'].'">'.$i.'</label></td>';
																			$content .= '<td>'.$csv['DMSCode'].'</td>';
																			$content .= '<td>'.$csv['reward_name'].'</td>';
																			$content .= '<td>'.$csv['EmailId'].'</td>';
																			$content .= '<td>'.$csv['mobile_no'].'</td>';
																			$content .= '<td>'.$csv['address'].'</td>';
																			$content .= '<td>'.$csv['address1'].'</td>';
																			$content .= '<td>'.$csv['LandMark'].'</td>';
																			$content .= '<td>'.$csv['Pincode'].'</td>';
																			$content .= '<td>'.$csv['State'].'</td>';
																			$content .= '<td>'.$csv['City'].'</td>';
																			$content .= '<td>'.$csv['verify_code'].'</td>';
																			$content .= '<td>'.$csv['reward'].'</td>';
																			$content .= '</tr>';
																			$i++;
																		}
																		echo $content;
																	}
																?>
															
															</tbody>
														</table>
													</div>
													<div class="" style="margin: 50px 0px;">
														<button type="button" name="send_sms" class="btn btn-success send_sms pull-right">Send SMS</button>
													</div>
												</div>
											</div>
						
											</div>
										</div>
									</div>
								</div>
							</div>
								
						</div>
					</div>
					
					</div>                    
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->
            
        </div>
        <!-- END CONTAINER -->
<script>
$('document').ready(function(){
	
	/*checked and unchecked all event*/
	$('body').on('click','.checked_unchecked_all',function(){
		$.blockUI();
		if($(this).val()== 'checked'){
			$('.select_mem').prop('checked',true);
		}else if($(this).val()== 'unchecked'){
			$('.select_mem').prop('checked',false);
		}
		$.unblockUI();
		
	});
	
	
	
	//----------------------------------------------------------
	/*sending the sms*/
	$('body').on('click','.send_sms',function(){
		var sender_list = [];
		$('#admin_table tbody tr').each(function(){
			if($(this).find('td:eq(0)').find('input[type="checkbox"].select_mem').is(':checked')==true){
				var reward_id = $(this).find('td:eq(0)').find('input[type="checkbox"].select_mem').val();
				var mobile_no = $(this).find('td:eq(0)').find('input[type="checkbox"].select_mem').attr('mobile');
				var security_key = $(this).find('td:eq(0)').find('input[type="checkbox"].select_mem').attr('security_key');
				sender_list.push({
					reward_id : reward_id,
					mobile_no : mobile_no,
					security_key : security_key,
				}); 
			}
		});
		if(sender_list.length==0){
			alert('Please select at least one');
			return false;
		}
		console.log(sender_list);
		$.post(APP_URL+'configure_access/send_to_sms',{
			sender_list : sender_list,
		},function(response){
			$('#headerMsg2').empty();
			if (response.status == 200) {
				$('#headerMsg2').html("<div class='alert alert-success fade in'>\n\<button class='close' type='button' data-dismiss='alert'>x</button>\n\<strong>" + response.message + "</strong></div>");
			}
			else {
				$('#headerMsg2').html("<div class='alert alert-danger fade in'>\n\<button class='close' type='button' data-dismiss='alert'>x</button>\n\<strong>" + response.message + "</strong></div>");
			}
			$("#headerMsg2").fadeTo(8000, 500).slideUp(500, function(){
				$("#headerMsg2").alert('close');
			});
		},'json');
	});
	
	
});
			
</script>			