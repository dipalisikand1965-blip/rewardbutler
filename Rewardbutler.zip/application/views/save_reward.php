<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Business Rewards</title>

<!-- Bootstrap -->
<link href="<?php echo base_url();?>assets/css/plugins/bootstrap.css" rel="stylesheet">
<!--=== Add By Designer ===-->
<link href="<?php echo base_url();?>assets/css/plugins/style.css" rel="stylesheet">
<link href="<?php echo base_url();?>assets/css/plugins/responsive.css" rel="stylesheet">
<link href="<?php echo base_url();?>assets/fonts/fonts.css" rel="stylesheet">


<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/jquery-2.1.1.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="<?php echo base_url();?>assets/js/plugins/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets/js/plugins/jquery.form.min.js"></script>
<script src="<?php echo base_url();?>assets/js/plugins/jquery.validate.min.js"></script>
<!--script href="<?php echo base_url();?>assets/js/plugins/jquery.blockui.min.js"></script-->
<script src="<?php echo base_url();?>assets/js/constant.js"></script>
<script src="<?php echo base_url();?>assets/js/plugins/script.js"></script>

</head>
<body>
<!-- Header Start -->
<header class="header" id="header">
	<div class="container">
    	<div class="row">
        	<div class="logo">
            	<a href="#"><img src="<?php echo base_url();?>assets/images/logo-1.png" alt=""/></a>
                
            </div>
        </div>
    </div>
</header>
<!-- Header End -->
<?php
	if($reward_detail){
		$reward_id = $reward_detail[0]['reward_id'];
		$reward_name = $reward_detail[0]['reward_name'];
		$reward_namef = $reward_detail[0]['reward_namef'];
		$EmailId = $reward_detail[0]['EmailId'];
		$address = $reward_detail[0]['address'];
		$address1 = $reward_detail[0]['address1'];
		$mobile_no = $reward_detail[0]['mobile_no'];
		$LandMark = $reward_detail[0]['LandMark'];
		$Pincode = $reward_detail[0]['Pincode'];
		$State = $reward_detail[0]['State'];
		$City = $reward_detail[0]['City'];
		$reward = $reward_detail[0]['reward'];
		$Opted = $reward_detail[0]['Opted'];
		$verify_code = $reward_detail[0]['verify_code'];
	}else{
		$reward_id = 0;
		$reward_name = '';
		$reward_namef = '';
		$EmailId = '';
		$address = '';
		$address1 = '';
		$mobile_no = '';
		$LandMark = '';
		$Pincode = '';
		$State = '';
		$City = '';
		$reward = '';
		$Opted = '';
		$verify_code = '';
	}

?>
<style>
	label.error{
		color: red;
	}
</style>
<!-- Content Start -->
<section class="content clearfix">
	<div class="container">
    	<div class="row">
        	<!-- Col Start -->
        	<div class="col-sm-8 col-md-6 col-lg-5 center-block float">
            	<!-- Form Start -->
				<?php if($reward_id > 0){?>
            	<form class="form reward_form" id="reward_form" method="post">
                	<h1>Welcome </h1>
                    <h6>Please update below details</h6>
                    <input type="hidden" name="reward_id" id="reward_id" value="<?php echo $reward_id;?>">
                    <input type="hidden" name="verify_code" id="verify_code" value="<?php echo $verify_code;?>">
					<div id="headerMsg"></div>
					<div class="form-group">
                        <label>First Name:</label>
                        <input type="text" name="reward_name" id="reward_name" class="form-control" value="<?php echo $reward_name;?>">
                    </div>
					<div class="form-group">
                        <label>Last Name:</label>
                        <input type="text" name="reward_namef" id="reward_namef" class="form-control" value="<?php echo $reward_namef;?>">
                    </div>
					<div class="form-group">
                        <label>Email Id:</label>
                        <input type="email" name="EmailId" id="EmailId" class="form-control" value="<?php echo $EmailId;?>">
                    </div>
                    <div class="form-group">
                        <label>Address:</label>
                        <input type="text" name="address" id="address" class="form-control" value="<?php echo $address;?>">
                    </div>
                    <div class="form-group">
                        <label>Address 1:</label>
                        <input type="text" name="address1" id="address1" class="form-control" value="<?php echo $address1;?>">
                    </div>
                    <div class="form-group">
                        <label>Mobile:</label>
                        <input type="text" name="mobile_no" id="mobile_no" class="form-control" value="<?php echo $mobile_no;?>">
                    </div>
					<div class="form-group">
                        <label>Land Mark:</label>
                        <input type="text" name="LandMark" id="LandMark" class="form-control" value="<?php echo $LandMark;?>">
                    </div>
					<div class="form-group">
                        <label>Pincode:</label>
                        <input type="text" name="Pincode" id="Pincode" class="form-control" value="<?php echo $Pincode;?>">
                    </div>
					<div class="form-group">
                        <label>State:</label>
                        <input type="text" name="State" id="State" class="form-control" value="<?php echo $State;?>">
                    </div>
					<div class="form-group">
                        <label>City:</label>
                        <input type="text" name="City" id="City" class="form-control" value="<?php echo $City;?>">
                    </div>
					
                    <div class="form-group">
                        <label>Opted for:</label>
                         <input type="text" name="Opted" id="Opted"  class="form-control" disabled value="<?php echo $Opted;?>">
                    </div>
                    <div class="form-group">
                        <label>Do you want to change your Rewards?:</label>
                        <select class="form-control" name="reward" id="reward">
							<!--<option value="">Please Select</option>
                          <option value="Yes" <?php if($reward=='Yes' || $reward=='yes' || $reward=='Y' || $reward=='y') echo 'selected';?>>Yes</option>
                          <option value="No" <?php if($reward=='No' || $reward=='no' || $reward=='N' || $reward=='n') echo 'selected';?>>No</option>
                           -->
                          <option value="No" >No</option>
                       <option value="Yes" >Yes</option> </select>
                    </div>
                    <div class="form-btn">
                    	<button type="submit" class="btn btn-black">Update Rewards</button>
                    </div>    
                </form>
                <!-- Form End -->
                <div class="thanks" style="display:none;">
                	<h1> Thank you for updating your Business Rewards..</h1>
                </div>
				<?php }else{?>
                <div class="thanksdefualt">
                	<h1> Your code has been expired...</h1>
                </div>
				<?php }?>
            </div>
            <!-- Col End -->
        </div>
    </div>
</section>
<!-- Content End -->
<style>
.thanksdefualt {
    background: rgba(109,109,109,.73);
    padding: 250px 36px 250px;
    border-radius: 20px;
    -webkit-border-radius: 20px;
    -ms-border-radius: 20px;
    text-align: center;
}
.thanksdefualt h1 {
    color: #fff;
}
</style>
</body>
</html>