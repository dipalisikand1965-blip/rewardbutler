$('document').ready(function(){
	
	
	//-----------------------------------------------------------------------
    /* 
     * validation of add city
     */
	$('#reward_form').validate({
		ignore: [],
        rules: {
            reward_name: {
                required: true
            },
            reward_namef: {
                required: true
            },
			address: {
                required: true
            },
			EmailId: {
                required: true
            },
			LandMark: {
                required: true
            },
			Pincode: {
                required: true
            },
			State: {
                required: true
            },
			City: {
                required: true
            },
			mobile_no: {
                required: true
            },
			Opted: {
                required: true
            },
			reward: {
                required: true
            },
		},
		 messages: {
			reward_name: {
                required: "First Name is required"
            },
			reward_namef: {
                required: "Last Name is required"
            },
			address: {
                required: "Address is required"
            },
			EmailId: {
                required: "Email Id is required"
            },
			LandMark: {
                required: "LandMark is required"
            },
			mobile_no: {
                required: "Mobile No is required"
            },
			Pincode: {
                required: "Pincode is required"
            },
			State: {
                required: "State is required"
            },
			City: {
                required: "City is required"
            },
			Opted: {
                required: "Opted is required"
            },
			reward: {
                required: "Reward is required"
            },
		},
		submitHandler: function (form) {
			var reward_id = $('#reward_id').val();
			var verify_code = $('#verify_code').val();
            var reward_name = $('#reward_name').val();
            var reward_namef = $('#reward_namef').val();
            var EmailId = $('#EmailId').val();
			var address = $('#address').val();
            var address1 = $('#address1').val();
            var mobile_no = $('#mobile_no').val();
            var LandMark = $('#LandMark').val();
            var Pincode = $('#Pincode').val();
            var State = $('#State').val();
            var City = $('#City').val();
            var reward = $('#reward').val();
            var Opted = $('#Opted').val();
            
			$.post(APP_URL + 'welcome/update_reward', {
                verify_code: verify_code,
                reward_id: reward_id,
                reward_name: reward_name,
                reward_namef: reward_namef,
                EmailId: EmailId,
                address: address,
                address1: address1,
                mobile_no: mobile_no,
                LandMark: LandMark,
                Pincode: Pincode,
                State: State,
                City: City,
				reward: reward,
				Opted: Opted,
			},
			function (response) {
				$("html, body").animate({scrollTop: 0}, "slow");
                $('#headerMsg').empty();
				if (response.status == 200) {
                    var message = response.message;
					if(reward_id!=0){
						message = "Reward has been updated successfully!";
					}
					/*$('#headerMsg').html("<div class='alert alert-success fade in'>\n\
                        <button class='close' type='button' data-dismiss='alert'>x</button>\n\
                        <strong>" + message + "</strong></div>");*/
					$('.thanks').show();
					$('.form').hide();
				}
                else if (response.status == 201) {
                    /*$('#headerMsg').html("<div class='alert alert-danger fade in'>\n\
                        <button class='close' type='button' data-dismiss='alert'>x</button>\n\
                        <strong>" + response.message + "</strong></div>");*/
						$('.thanks').show();
					$('.form').hide();
                }
				
			}, 'json');
		return false;
		},
	});
	
	
});
