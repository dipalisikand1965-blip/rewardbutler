$('document').ready(function(){
	
	//---------------------------------------------------------------------
    /*
     * This script is used for logout user
     */
	$('body').on('click','.logout',function() {
		$.get(APP_URL+'configure_access/logout',{},function(response) {
			window.location.href = APP_URL;
		});			
	});
	
	
});