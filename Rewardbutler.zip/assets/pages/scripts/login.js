$(document).ready(function() {
    $('#register-btn').click(function() {
		$('.login-form').hide();
		$('.register-form').show();
	});

	$('#register-back-btn').click(function() {
		$('.login-form').show();
		$('.register-form').hide();
	});
	$('#forget-password').click(function() {
		$('.login-form').hide();
		$('.forget-form').show();
	});

	$('#back-btn').click(function() {
		$('.login-form').show();
		$('.forget-form').hide();
	});
	
	//-----------------------------------------------------------------------
    /* 
     * user_login_form validation
     */
	 $('.login-form').validate({
		rules: {
			loginUserEmail: {
				required: true
			},
			loginPassword: {
				required: true
			}
		},
		onkeyup: false,
		messages: {
			loginUserEmail: {
				required: 'User Email is required.'
			},
			loginPassword: {
				required: 'Password is required.'
			}
		},
		submitHandler: function (form) {
			$.blockUI();
			$('.login-form').find('button[type="submit"]').prop('disabled',true);
			
			var loginUserEmail = $("#loginUserEmail").val();
			var loginPassword = $("#loginPassword").val();
			/*Validating user supplied credentials*/
			$.post(APP_URL + 'welcome/check_login_credentials', {
				loginUserEmail: loginUserEmail,
				loginPassword: loginPassword
			},
			function (response) {
				$("#headerMsg").empty();
				if (response.status == 200) {
					//alert(response.message);
					window.location.replace(APP_URL+response.redirect);
				}
				else {
					$('#headerMsg').html("<div class='alert alert-danger fade in'>\n\
					<button class='close' type='button' data-dismiss='alert'>x</button>\n\
					<strong>Invalid Username or Password!</strong></div>");
					alert(response.message);
					$('.login-form').resetForm();
				}
				$('.login-form').find('button[type="submit"]').prop('disabled',false);
			}, 'json');
			$.unblockUI();
			return false;
		}
	});
	
	
});